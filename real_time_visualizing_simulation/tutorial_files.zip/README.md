- You need to run this notebook interactively to save to html file.

    amber.jupyter notebook notebook.ipynb

- How to update?

    - Run the notebook
    - Choose: File -> Download as -> HTML (.html)
    - Move generated notebook.html to this folder

- For fixing typos, just using VIM to edit ipynb and html files.
